package ejercicio1;

public abstract class Figure {
	
	public void draw() { //declaration of draw method
	
		System.out.println("I am a triangle");
		
	}

}
