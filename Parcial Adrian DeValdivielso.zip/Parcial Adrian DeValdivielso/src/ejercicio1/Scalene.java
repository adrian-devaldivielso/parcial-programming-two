package ejercicio1;

public class Scalene extends Triangle{ //"Scalene" is inheriting the methods from "Triangle"
	
	public void getArea(double d, double e) { //Implementation of "Operable" methods
		
		System.out.println("Area: " + (d*e/2));
		
	}

	public void getPerimeter(double d, double e, double f) { //Implementation of "Operable" methods
		
		System.out.println("Perimeter: " + (d+e+f));
		
	}

}
