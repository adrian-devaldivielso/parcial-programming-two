package ejercicio1;

public class Equilateral extends Triangle{ //"Equilateral" is inheriting the methods from "Triangle"

	public void getArea(double d, double e) { //Implementation of "Operable" methods
		
		System.out.println("Area: " + (d*e/2));
		
	}

	public void getPerimeter(double d, double e, double f) { //Implementation of "Operable" methods
		
		System.out.println("Perimeter: " + (d+e+f));
		
	}
	
}
