package ejercicio1;

public class Triangle extends Figure implements Operable{ //"Triangle" implements from the interface "Operable"

	public static void main(String[] args) {
		
		Isosceles triangle1 = new Isosceles(); //creating an example triangle
		
		triangle1.draw(); //calling overwritten implementation of the method from "Figure"
		
		triangle1.getArea(12.3, 45.6); //calling the getArea method from "Operable"
		
		triangle1.getPerimeter(12.3, 45.6, 78.9); //calling the getPerimeter method from "Operable"

	}
	
}
