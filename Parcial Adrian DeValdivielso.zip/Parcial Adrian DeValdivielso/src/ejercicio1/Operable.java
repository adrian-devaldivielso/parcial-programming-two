package ejercicio1;

public interface Operable {

	public static double getArea(double a, double b) { //declaration of getArea method
		
		return a*b/2;
		
	} 
	
	public static double getPerimeter(double a, double b, double c) { //declaration of getPerimeter method
		
		return a+b+c;
		
	}
	
}
