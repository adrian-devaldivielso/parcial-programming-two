package ejercicio2;

public class Calculadora implements Calculable{

	protected float n1;
	
	protected float n2;
	
	public Calculadora(float n1, float n2) {
		
		this.n1 = n1;
		
		this.n2 = n2;
		
	}

	public void cargarOperandos(float n1, float n2) {
		
		this.n1 = n1;
		
		this.n2 = n2;
		
	}
	
	public float sumarOperandos() {
	
		return (this.n1 + this.n2);
		
	}
	
	public float restarOperandos() {
		
		return (this.n1 - this.n2);
		
	}
	
	public float multiplicarOperandos() {
		
		return (this.n1 * this.n2);
		
	}
	
	public float dividirOperandos() {
		float result = 0;
		
		if(this.n2==0) {
			
			System.out.println("Error matemático");
			
		} else {
		
		result = (this.n1 / this.n2);
		
		}
		return result;
	}
	
}
	
