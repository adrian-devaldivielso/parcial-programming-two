package ejercicio2;

public class CalcV2 extends Calculadora{

	public CalcV2(float n1, float n2) {
		
		super(n1, n2);
		
	}
	
	public float restoDivision() { //If this were declared as a "public Object" rather than a public float
		float result = 0;		   //it would save some lines of code, simplifying the System.out.print to 
								   //return "Mathematical error", and removing the need for a float "result"
		if(this.n2==0) {
			
			System.out.println("Mathematical error");
			
		} else {
		
		result = (this.n1 % this.n2);
		
		}
		
		return result;
		
		
	}

	public static void main(String[] args) {
		
		CalcV2 myCalculator = new CalcV2(15, 0);
		
		if(myCalculator.isDivisible()) {
			
			System.out.println(myCalculator.n1 + " can be divided by " + myCalculator.n2);
			
		}
		
		else {
		
		System.out.println("Selected numbers cannot be divided");
		
		}
		
	}

	public boolean isDivisible() {
		
		if(this.n2==0) {
			
			return false;
			
		} else {
			
			return true;
			
		}
	}

}
