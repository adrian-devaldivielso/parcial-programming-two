package ejercicio2;

public interface Calculable {

	public static boolean isDivisible(double a, double b) { //declaration of getArea method
		
		if(b==0) {
			
			return false;
			
		} else {
			
			return true;
			
		}
		
		
		
	} 
	
}
